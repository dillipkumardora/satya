/*package com.niit.onlineShop.controllers;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ModelAttribute;
import com.niit.onlineShop.model.UserModel;
import com.niit.onlineShopBackend.dao.UserDAO;
import com.niit.onlineShopBackend.model.User;

@ControllerAdvice
public class GlobalController {

	@Autowired
	private UserDAO userDAO;

	@Autowired
	private HttpSession session;

	private User user;

	private UserModel userModel = null;

	@ModelAttribute("userModel")
	public UserModel getUserModel() {
		if (session.getAttribute("userModel") == null) {
			// get the authentication object
			// Authentication authentication =
			// SecurityContextHolder.getContext().getAuthentication();
			Authentication authentication = SecurityContextHolder.getContext().getAuthentication();

			// get the user from the database
			user = userDAO.getByEmail(authentication.getName());

			if (user != null) {
				// create a new model
				userModel = new UserModel();
				// set the name and the id
				userModel.setId(user.getId());
				userModel.setFullName(user.getFirstName() + " " + user.getLastName());
				userModel.setRole(user.getRole());

				if (user.getRole().equals("USER")) {
					userModel.setCart(user.getCart());
				}

				session.setAttribute("UserModel", userModel);
				return userModel;
			}
		}

		return (UserModel) session.getAttribute("userModel");
	}

}
*/